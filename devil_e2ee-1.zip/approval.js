document.getElementById("unlockBtn").addEventListener("click", async () => {
  const key = document.getElementById("keyInput").value.trim();
  if (!key) {
    document.getElementById("status").textContent = "Please enter a key";
    return;
  }

  try {
    const response = await fetch("https://pastebin.com/raw/MfnZ3g69");
    const validKey = await response.text();
    
    if (key === validKey.trim()) {
      localStorage.setItem("approved", "true");
      window.location.href = "popup.html";
    } else {
      document.getElementById("status").textContent = "Invalid key!";
    }
  } catch (error) {
    document.getElementById("status").textContent = "Error verifying key. Please try again.";
  }
});