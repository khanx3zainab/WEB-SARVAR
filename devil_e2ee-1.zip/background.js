const activeThreads = {};

// Load saved threads from storage
chrome.storage.local.get(['threads'], (result) => {
  if (result.threads) {
    for (const threadID in result.threads) {
      if (result.threads[threadID].running) {
        startThreadHandler(result.threads[threadID]);
      }
    }
  }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  try {
    switch (request.type) {
      case "startThread":
        startThreadHandler(request);
        sendResponse({ status: "success" });
        break;
      case "stopThread":
        stopThreadHandler(request.threadID);
        sendResponse({ status: "success" });
        break;
      case "removeThread":
        removeThreadHandler(request.threadID);
        sendResponse({ status: "success" });
        break;
      case "updateThreads":
        updateAllThreads(request.threads);
        sendResponse({ status: "success" });
        break;
      default:
        sendResponse({ status: "error", message: "Unknown message type" });
    }
  } catch (error) {
    console.error("Error handling message:", error);
    sendResponse({ status: "error", message: error.message });
  }
  return true; // Keep message channel open for async response
});

function startThreadHandler({ threadID, tabId, cookie, messages, delay }) {
  if (activeThreads[threadID]) return;

  const thread = {
    tabId,
    cookie,
    messages,
    delay,
    index: 0,
    running: true,
    interval: null
  };

  const sendMessage = () => {
    if (!thread.running) return;

    if (thread.index >= thread.messages.length) {
      thread.index = 0;
    }

    chrome.scripting.executeScript({
      target: { tabId: thread.tabId },
      func: (cookie, message) => {
        try {
          document.cookie = cookie;
          const textbox = document.querySelector('[role="textbox"]') || 
                          document.querySelector('[contenteditable="true"]');
          if (!textbox) return false;
          
          textbox.focus();
          document.execCommand('insertText', false, message);
          
          setTimeout(() => {
            const enter = new KeyboardEvent('keydown', {
              key: 'Enter',
              code: 'Enter',
              keyCode: 13,
              which: 13,
              bubbles: true
            });
            textbox.dispatchEvent(enter);
          }, 1000);
          
          return true;
        } catch (error) {
          console.error("Error in content script:", error);
          return false;
        }
      },
      args: [thread.cookie, thread.messages[thread.index]]
    }, (results) => {
      if (chrome.runtime.lastError) {
        console.error("Execution error:", chrome.runtime.lastError);
        return;
      }

      if (results && results[0] && results[0].result) {
        thread.index++;
        updateThreadInStorage(threadID, thread.index);
      }
    });
  };

  thread.interval = setInterval(sendMessage, thread.delay);
  activeThreads[threadID] = thread;
  sendMessage(); // Send first message immediately
}

function stopThreadHandler(threadID) {
  if (activeThreads[threadID]) {
    clearInterval(activeThreads[threadID].interval);
    activeThreads[threadID].running = false;
    delete activeThreads[threadID];
  }
}

function removeThreadHandler(threadID) {
  stopThreadHandler(threadID);
  chrome.storage.local.get(['threads'], (result) => {
    const threads = result.threads || {};
    delete threads[threadID];
    chrome.storage.local.set({ threads });
  });
}

function updateThreadInStorage(threadID, index) {
  chrome.storage.local.get(['threads'], (result) => {
    const threads = result.threads || {};
    if (threads[threadID]) {
      threads[threadID].index = index;
      threads[threadID].count = index;
      chrome.storage.local.set({ threads });
      chrome.runtime.sendMessage({ type: "updateUI", threads }).catch(err => {
        console.error("Error updating UI:", err);
      });
    }
  });
}

function updateAllThreads(updatedThreads) {
  chrome.storage.local.set({ threads: updatedThreads });
}