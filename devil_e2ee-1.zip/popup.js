document.addEventListener("DOMContentLoaded", () => {
  // First check if approved
  checkApproval();

  const sendBtn = document.getElementById("send");
  const fileInput = document.getElementById("file");
  const delayInput = document.getElementById("delay");
  const threadList = document.getElementById("threads");

  let threads = JSON.parse(localStorage.getItem("threads") || "{}");

  function checkApproval() {
    const isApproved = localStorage.getItem("approved") === "true";
    if (!isApproved) {
      window.location.href = "approval.html";
      return;
    }
  }

  function saveThreads() {
    localStorage.setItem("threads", JSON.stringify(threads));
    chrome.runtime.sendMessage({ 
      type: "updateThreads", 
      threads 
    }).catch(err => {
      console.error("Error sending message:", err);
    });
  }

  // Load existing threads from storage
  chrome.storage.local.get(['threads'], (result) => {
    if (result.threads) {
      threads = result.threads;
      updateThreadsUI();
    }
  });

  sendBtn.addEventListener("click", async () => {
    const cookie = document.getElementById("cookie").value.trim();
    const threadID = document.getElementById("thread").value.trim();
    const prefix = document.getElementById("prefix").value.trim();
    const delay = parseInt(delayInput.value.trim()) * 1000;

    if (!cookie || !threadID || !fileInput.files.length || isNaN(delay)) {
      alert("Please fill all fields and select a .txt file.");
      return;
    }

    if (threads[threadID]) {
      alert("Thread already exists in history or running!");
      return;
    }

    try {
      const file = fileInput.files[0];
      const messages = await readFile(file, prefix);
      
      const url = `https://www.facebook.com/messages/t/${threadID}`;
      threads[threadID] = { url, messages, delay, index: 0, count: 0, running: true, cookie };
      saveThreads();

      const tab = await chrome.tabs.create({ url });
      
      await chrome.runtime.sendMessage({ 
        type: "startThread", 
        threadID, 
        tabId: tab.id,
        cookie,
        messages,
        delay
      });
      
      updateThreadsUI();
    } catch (error) {
      console.error("Error:", error);
      alert("An error occurred: " + error.message);
    }
  });

  function readFile(file, prefix) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const messages = reader.result.split("\n")
          .map(m => prefix + m.trim())
          .filter(Boolean);
        if (!messages.length) {
          reject(new Error("The message file is empty!"));
          return;
        }
        resolve(messages);
      };
      reader.onerror = () => reject(new Error("Failed to read file"));
      reader.readAsText(file);
    });
  }

  function updateThreadsUI() {
    threadList.innerHTML = '';
    for (const id in threads) {
      const t = threads[id];
      const div = document.createElement("div");
      div.className = "thread-box";
      div.innerHTML = `
        <div class="thread-header">🧵 <a href="${t.url}" target="_blank">${id}</a></div>
        <div class="thread-details">
          ⏱ Delay: ${t.delay / 1000}s<br/>
          📨 Sent: ${t.count} / ${t.messages.length}<br/>
          🔁 Status: ${t.running ? "🟢 Active" : "🔴 Stopped"}
        </div>
        <button data-id="${id}" class="stop-btn">⛔ Stop</button>
        <button data-id="${id}" class="close-btn">❌ Remove</button>
      `;
      threadList.appendChild(div);
    }

    document.querySelectorAll(".stop-btn").forEach(btn => {
      btn.addEventListener("click", async () => {
        const id = btn.getAttribute("data-id");
        if (threads[id]) {
          threads[id].running = false;
          saveThreads();
          updateThreadsUI();
          try {
            await chrome.runtime.sendMessage({ type: "stopThread", threadID: id });
          } catch (error) {
            console.error("Error stopping thread:", error);
          }
        }
      });
    });

    document.querySelectorAll(".close-btn").forEach(btn => {
      btn.addEventListener("click", async () => {
        const id = btn.getAttribute("data-id");
        delete threads[id];
        saveThreads();
        updateThreadsUI();
        try {
          await chrome.runtime.sendMessage({ type: "removeThread", threadID: id });
        } catch (error) {
          console.error("Error removing thread:", error);
        }
      });
    });
  }

  // Listen for updates from background
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type === "updateUI") {
      threads = request.threads;
      updateThreadsUI();
    }
  });

  updateThreadsUI();
});